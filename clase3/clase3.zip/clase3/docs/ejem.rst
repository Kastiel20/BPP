ejem module
===========

.. automodule:: ejem
   :members:
   :undoc-members:
   :show-inheritance:
