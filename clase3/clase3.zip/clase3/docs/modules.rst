code
====

.. toctree::
   :maxdepth: 4

   operaciones
   ejem
